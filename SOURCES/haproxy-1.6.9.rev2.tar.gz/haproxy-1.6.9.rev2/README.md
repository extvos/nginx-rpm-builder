# A fork of HAproxy

[![Build Status](https://travis-ci.org/archsh/haproxy.svg?branch=master)](https://travis-ci.org/archsh/haproxy)

## Updates:
- Negative number for balance uri depth supported

## TODO:
- Grouping backends
